package demo.domain

import spock.lang.Specification

class OrderTest extends Specification {
    def "SetQuantity"() {
        given:
        def order = new Order()

        when :
        order.setQuantity(2)

        then :
        order.getQuantity() == 2
    }

    def "SetItemName"() {

        given :
        def order = new Order()

        when :
        order.setItemName("order1")

        then :
        order.getItemName() == "order1"
    }

    def "SetPrice"() {

        given :
        def order = new Order()

        when :
        order.setPrice(15200)

        then :
        order.getPrice() == 15200

    }

    def "SetPriceWithTax"() {

        given :
        def order = new Order()

        when :
        order.setPriceWithTax(16500)

        then :
        order.getPriceWithTax() == 16500
    }
}
