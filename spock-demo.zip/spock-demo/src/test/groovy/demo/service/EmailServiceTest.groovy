package demo.service

import demo.domain.Order
import spock.lang.Specification

class EmailServiceTest extends Specification {
    def "SendEmail"() {
        setup :
        EmailService emailServiceTest = EmailService.getInstance()

        and:
        def order = Mock(Order)

        when :
        emailServiceTest.sendEmail(order)

        then :
        thrown(RuntimeException)

    }


    def "SendEmail1"() {
        setup :
        EmailService emailServiceTest = EmailService.getInstance()

        and :
        def order = Mock(Order)

        and :
        String cc = "new string"

        and :
        emailServiceTest.sendEmail1(order, cc)

        when :
        boolean mail = emailServiceTest.sendEmail1(order,cc)

        then :
        mail
    }
}
